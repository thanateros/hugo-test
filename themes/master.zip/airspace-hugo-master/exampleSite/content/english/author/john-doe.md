---
title: "John Doe"
email: "email2@example.org"
bg_image: "images/feature-bg.jpg"
draft: false
social:
  - icon : "ion-social-facebook-outline" #ionicon pack v2 : https://ionicons.com/v2/
    link : "#"
  - icon : "ion-social-twitter-outline" #ionicon pack v2 : https://ionicons.com/v2/
    link : "#"
  - icon : "ion-social-pinterest-outline" #ionicon pack v2 : https://ionicons.com/v2/
    link : "#"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. Duis auctor lacus id vehicula gravida. Nam suscipit vitae purus et laoreet.
Donec nisi dolor, consequat vel pretium id, auctor in dui. Nam iaculis, neque ac ullamcorper.